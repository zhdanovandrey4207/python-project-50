#!/usr/bin/env pyhton3
from gendiff import generate_diff


generate_diff('file1.json','file2.json')
